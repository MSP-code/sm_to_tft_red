#ifndef _DELAY_H
#define _DELAY_H

void delay_us(unsigned int time);

void delay_ms(unsigned int time);

#endif

