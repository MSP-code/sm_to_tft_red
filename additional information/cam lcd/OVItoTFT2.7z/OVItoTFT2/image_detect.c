#include "image_detect.h"
#include "alt_types.h"
#define nthreshold 5
#define RMove 11
#define GMove 6
//unsigned char count=0;
void rgbtogray(unsigned char *srgb,unsigned char *sgray,int nwidth,int nheight)
{
 int i,j;
 int t;
 int r, g, b;
 for(j=0;j<nheight;j++)
    {
     for(i=0;i<nwidth;i++)
        {
         //sgray[nwidth*j+i]=(5*srgb[3*(nwidth*j+i)]+3*srgb[3*(nwidth*j+i)+1]+2*srgb[3*(nwidth*j+i)+2])/10;   
         r= srgb[nwidth*j+i] >> RMove;
         g= (0x07ff & srgb[nwidth*j+i]) >> GMove;
         b= 0x001f & srgb[nwidth*j+i];
         t = (r*3+b*6+g)/10; 
         sgray[nwidth*j+i] = (t<<RMove)|(t<<GMove)|t;   
        }       
    }
}

void diffimage(unsigned char *sgray,unsigned char *pgray,int nwidth,int nheight)
{
    int i,j;
    int diff;
    for(j=0;j<nheight;j++)
    {
        for(i=0;i<nwidth;i++)
        {
            diff = sgray[j*nwidth+i]-pgray[nwidth*j+i];
            if((diff>nthreshold ) || (diff< -nthreshold))
               {
                    m_pdiffimage[j*nwidth+i] = 1;//255;
               }
            else
               {
                    m_pdiffimage[j*nwidth+i] = 0;
               }  
        }   
    }   
}

void getmultdata(unsigned char *sgray,int nwidth,int nheight)
{
    int i,j;
//    count++;
    for(j=0;j<nheight;j++)
        for(i=0;i<nwidth;i++)
            m_ptemplate[j*nwidth+i] = sgray[j*nwidth+i];   
}

void getbgimage(int nwidth,int nheight)
{
    int i,j,t;
    unsigned char pixel;
    for(j=0;j<nheight;j++)
        {
         for(i=0;i<nwidth;i++)
            {
                t = j*nwidth+i;
                pixel = (m_ptemplate[t]+0.5);
                if(pixel>255)
                    m_pbackground[t] = 255;
                else
                    if(pixel<0)
                         m_pbackground[t] = 0;
                    else
                         m_pbackground[t] = pixel;
            }   
            
        }   
}
