#ifndef _VARIABLE_H_
#define _VARIABLE_H_


#define uchar unsigned char
//#define uint  unsigned int
#define ulong unsigned long

#endif
