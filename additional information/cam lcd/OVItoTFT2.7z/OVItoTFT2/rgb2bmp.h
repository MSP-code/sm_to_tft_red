#ifndef _RGB2BMP_H
#define _RGB2BMP_H

void RGB565_TO_BMP(alt_u16 *RGB565,alt_u8 *BMP);

#endif
