#ifndef IMAGE_DETECT_H_
#define IMAGE_DETECT_H_
#include "alt_types.h"
extern unsigned char *m_pdiffimage;
extern unsigned int *m_ptemplate;
extern unsigned char *m_pbackground;
extern unsigned char *m_pgrayimage;

void rgbtogray(unsigned char *srgb,unsigned char *sgray,int nwidth,int nheight);
void diffimage(unsigned char *sgray,unsigned char *pgray,int nwidth,int nheight);
void getmultdata(unsigned char *sgray,int nwidth,int nheight);
void getbgimage();

#endif /*IMAGE_DETECT_H_*/
